import express  from 'express';
import connection from './config.js';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';


const app = express();
const PORT = process.env.PORT || 3000;

app.disable('x-powered-by');

app.use(express.json());

const _dirname = dirname(fileURLToPath(import.meta.url));
app.disable('x-powered-by');
app.use(express.json());

app.get('/libros', (req, res) => {
    res.sendFile(join(_dirname, 'public', 'libros.html'));
});

app.get('/autores', (req, res) => {
    res.sendFile(join(_dirname, 'public', 'autores.html'));
});

// Obtener todos los libros
app.get("/api/libros", (_, res) => {
    connection.query("SELECT * FROM db_libros.libros;", (error, rows) => {
        if (error) {
            res.status(500).json({ error: error.message });
        } else {
            res.json(rows);
        }
    })
});

// Obtener todos los autores
app.get("/api/autores", (_, res) => {
    connection.query("SELECT * FROM db_libros.autores;", (error, rows) => {
        if (error) {
            res.status(500).json({ error: error.message });
        } else {
            res.json(rows);
        }
    })
});

// Obtener un libro por su id
app.get("/api/libros/:id", (req, res) => {
    // [req.params.id] trae el valor de :id
    const { id } = req.params;
    connection.query("SELECT Id_Libro, Titulo, Editorial, Fecha_pub FROM db_libros.libros where Id_Libro = ?;", [id], (error, rows) => {
        if (error) return res.status(500).json({ error: error.message });
        if (rows.length === 0) return res.status(404).json({ error: "No existe el recurso" });
        res.json(rows[0]);
    })
})

// Obtener un autor por su id
app.get("/api/autor/:id", (req, res) => {
    // [req.params.id] trae el valor de :id
    const { id } = req.params;
    connection.query("SELECT Autor_Id, Nombre, Nacionalidad, Fecha_nacimiento FROM db_libros.autores where Autor_Id = ?;", [id], (error, rows) => {
        if (error) return res.status(500).json({ error: error.message });
        if (rows.length === 0) return res.status(404).json({ error: "No existe el recurso" });
        res.json(rows[0]);
    })
})

app.listen(PORT, () => {
    console.log(`Servidor conectado a http://localhost:${PORT}`);
});
