app.disable('x-powered-by');

app.use(express.json());
// pedniente middleware para archivos estáticos

// primer enpoint TRAER TODOS LOS DISCOS
app.get('/discos', (req, res) => {
  const query =
    'SELECT id, nombre, Artista, fecha_pub, Discografica, precio FROM discos';

  connection.query(query, (err, rows) => {
    if (err) {
      console.log('Error ejecutando la consulta', err.message);
      res.status(500).send('Error en el servidor');
      return;
    }

    res.json(rows);
  });
});

// SEGUNDO enpoint TRAER UN DISCO ESPECÍFICO
app.get('/discos/:id', (req, res) => {
  const query =
    'SELECT id, nombre, Artista, fecha_pub, Discografica, precio FROM discos WHERE id= ? ';
  const { id } = req.params;

  connection.query(query, [id], (err, rows) => {
    if (err) {
      console.log('Error ejecutando la consulta', err.message);
      res.status(500).send('Error en el servidor');
      return;
    }

    if (rows.length === 0) {
      res.status(404).send('Disco no encontrado');
      return;
    }

    res.json(rows[0]);
  });
});

// CREACION DE UN NUEVO RECURSO Y EN BASE DE DATOS REGISTRO
app.post('/discos', (req, res) => {
  const { nombre, Artista, fecha_pub, Discografica, Precio } = req.body;

  if (!nombre || !Artista || !fecha_pub || !Discografica || !Precio) {
    res.status(400).send('Faltan campos obligatorios');
    return;
  }

  const query =
    'INSERT INTO discos (nombre, Artista, fecha_pub, Discografica, Precio) VALUES (?, ?, ?, ?, ?)';

  connection.query(
    query,
    [nombre, Artista, fecha_pub, Discografica, Precio],
    (err, results) => {
      if (err) {
        console.error('Error ejecutando la consulta:', err.message);
        res.status(500).send('Error en el servidor');
        return;
      }

      res.status(201).json({ id: results.insertId, message: 'Disco creado' });
    }
  );
});

app.put('/discos/:id', (req, res) => {
  const { id } = req.params;
  const { nombre, Artista, fecha_pub, Discografica, Precio } = req.body;

  if (!nombre || !Artista || !fecha_pub || !Discografica || !Precio) {
    res.status(400).send('Faltan campos obligatorios');
    return;
  }

  const query =
    'UPDATE discos SET nombre = ?, Artista = ?, fecha_pub = ?, Discografica = ?, Precio = ? WHERE id = ? ';

  connection.query(
    query,
    [nombre, Artista, fecha_pub, Discografica, Precio, id],
    (err, results) => {
      if (err) {
        console.error('Error ejecutando la consulta:', err.message);
        res.status(500).send('Error en el servidor');
        return;
      }

      if (results.affectedRows === 0) {
        res.status(404).send('Disco no encontrado');
        return;
      }

      res.json({ message: 'Disco actualizado' });
    }
  );
});

app.patch('/discos/:id', (req, res) => {
  const { id } = req.params;
  const fields = req.body;

  const query = `UPDATE discos SET ${Object.keys(fields)
    .map(key => `${key} = ?`)
    .join(', ')} WHERE id = ? `;

  connection.query(query, [...Object.values(fields), id], (err, results) => {
    if (err) {
      console.error('Error ejecutando la consulta:', err.message);
      res.status(500).send('Error en el servidor');
      return;
    }

    if (results.affectedRows === 0) {
      res.status(404).send('Disco no encontrado');
      return;
    }

    res.json({ message: 'Disco Actualizado parcialmente' });
  });
});

app.delete('/discos/:id', (req, res) => {
  const { id } = req.params;

  const query = 'DELETE FROM discos WHERE id = ?';

  connection.query(query, [id], (err, results) => {
    if (err) {
      console.error('Error ejecutando la consulta:', err.message);
      res.status(500).send('Error en el servidor');
      return;
    }

    if (results.affectedRows === 0) {
      res.status(404).send('Disco no encontrado');
      return;
    }

    res.json({ message: 'Disco eliminado' });
  });
});

app.listen(PORT, () => {
  console.log(`Servidor conectado a http://localhost:${PORT}`);
});